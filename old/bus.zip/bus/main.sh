#!/bin/bash


# video options

fps=5
width=640
height=480
endpos=600
diskspace=90
output_dir="/mnt/flash"
compression=":outfmt=mjpeg"

rm /var/log/*.gz

killall -CONT mencoder
killall mencoder

sleep 15

#if [ -e /mnt/flash/root/main.sh ]
#then
#	umount /mnt/flash
#fi

rm /root/pid/*.pid

counter=0
currpid=0

while [ 1 ]
do
    output=$( mount -l | grep -oE '/mnt/flash' )
    if [ $output ] 
    then
	if [ ! -e /mnt/flash/processing ]
	then
		mkdir /mnt/flash/processing
	fi

	output=$( df /mnt/flash | grep -oE [0-9]+% | grep -oE [0-9]+ )
	echo "Used space: $output %"
	
	while [ $output -ge $diskspace ]
	do
	    echo "Clearance needed"
	    ls -tr /mnt/flash/*.avi | head -n 10 | xargs rm
	    
	    output=$( df /mnt/flash | grep -oE [0-9]+% | grep -oE [0-9]+ )
	    echo "Used space: $output %"
	done	
	
	for video_device in /dev/webca*
	do
	    echo "$video_device detected"
	    proclist=$( ps aux )
	    encoder=$( echo $proclist | grep -oE device=$video_device )
	    echo "Encoder:[$encoder]"
	    if [ ! $encoder ] 
	    then
		echo "No encoder present for device $video_device"
		device=$( echo $video_device | grep -oE 'webcam[0-9]+' )
		echo "Device: $device"
		
		prop=$( udevadm info -q all -n $video_device | grep -oE ID_MODEL_ID=[0-9a-f]+ | grep -oE [0-9a-f]+ )

		if [ $device == "webcam0" ]
		then
			echo "Counter camera found"
			mencoder -quiet -tv width=320:height=200:device=/dev/webcam0:fps=30 -nosound -ovc lavc -lavcopts vcodec=mpeg4 -o $output_dir/processing/$device-`date +%d.%m.%Y_%H.%M.%S.avi` tv:// -endpos 300 &> /dev/null &
			sleep 2
			proclist=$( ps -U root o pid,cmd )
			encoder=$( echo $proclist | grep -oE '[0-9]+\s+mencoder -quiet -tv width=320:height=200:device=/dev/webcam0' | grep -oE ^[0-9]+ )
			echo "Encoder PID: $encoder"
			currpid=$encoder
			counter=0
			st=$( cat /root/pid/door.state )
			if [ $st == 1 ] 
			then
				echo "Door opened, recording"
			else
				echo "Door closed, suspending"
				kill -SIGSTOP $encoder
			fi
			echo $encoder > /root/pid/webcam0.pid
		else
			if [ $prop == "081b" ]
			then
		    		echo "Running WITHOUT compression for device: $video_device"
		    		mencoder -quiet -tv width=$width:height=$height:device=/dev/$device:fps=$fps -nosound -ovc lavc -lavcopts vcodec=mpeg4 -o $output_dir/$device-`date +%d.%m.%Y_%H.%M.%S.avi` tv:// -endpos $endpos &> /dev/null &	    
		    		sleep 2
			else
		    		echo "Running WITH compression for device: $video_device"
	    	    		mencoder -quiet -tv width=$width:height=$height:device=/dev/$device:outfmt=mjpeg:fps=$fps -nosound -ovc lavc -lavcopts vcodec=mpeg4 -o $output_dir/$device-`date +%d.%m.%Y_%H.%M.%S.avi` tv:// -endpos $endpos &> /dev/null &	    
		    		sleep 2
			fi
		fi
	    else
		echo "Encoder for device $video_device running"
		if [ $video_device == "/dev/webcam0" ]
		then
			counter=$(($counter+1))
			echo "Safety counter: $counter"
			if [ $counter -gt 350 ]
			then
				kill -SIGCONT $currpid
			fi
		fi
	    fi
	done
	
	output=$( ls /mnt/flash/processing/*.avi | wc -l )	
	if [ $output -gt 1 ]
	then
		echo "Files for processing present"
		output=$( ps aux )
		sr=$( echo $output | grep -oE sensor.sh )
	  	if [ ! $sr ]
		then
			echo "About to run counter..."
			file=$( ls -tr /mnt/flash/processing/*.avi | head -n 1 | grep -oE 'web.*' )
			echo $file
			/root/sensor.sh $file &
		else
			echo "Counter process already running, waiting..."
		fi	
		
	fi
	
    else
	echo "Waiting for flash..."
    fi

    sleep 1
done 
